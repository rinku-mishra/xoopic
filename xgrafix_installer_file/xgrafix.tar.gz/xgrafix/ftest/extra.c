/**********************************************/

void Dump(filename)
char *filename;
{
  /* The user's dump routine should go here.  */
}  /* End DUMP */

/**********************************************/

void Quit()
{
  /* The user's quit routine should go here.  */
}  /* End QUIT */

