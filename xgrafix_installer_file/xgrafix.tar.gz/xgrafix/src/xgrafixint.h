#ifndef XGRAFIXINT_H
#define XGRAFIXINT_H

/************************/
/* Including the C libs */

#include <stdio.h>
#include <unistd.h>
//#include <malloc/malloc.h>
#include <string.h>
#include <time.h>
#include <math.h>
#include <stdlib.h>

/************************/
/* Including the X libs */

#include <X11/Xlib.h>
#include <X11/Xutil.h>

/*****************************/
/* Including the Tcl/Tk libx */

#ifndef USE_INTERP_RESULT
	#define USE_INTERP_RESULT
#endif

#include <tcl.h>
#include <tk.h>

/********************/
/* Some data macros */
#include "xgdatamacros.h"

/*****************************/
/* the non-X global variables and data types */
#include "xgminint.h"


/****************************************/
/* XGrafix version number               */
static const char *xgversion = "2.70.7";

/****************************************/
/* Definition of colors used in XGrafix */

static const char *WindowTextColor   = "cyan";
static const char *BorderColor       = "red";
static const char *TickMarkColor     = "yellow";
static const char *BackgroundColor   = "black";

#define		MAXGRAYSHADES	 11

static const char *theGrayShades[]={	"gray0",  "gray10", "gray20",
				"gray30", "gray40", "gray50",
				"gray60", "gray70", "gray80",
				"gray90", "gray100"};

#define		MAXCOLORS	 9

static const char *theColorNames[]={	"cyan", "wheat", "green", 
				"yellow", "orange", "pink",
				"lightblue", "brown", "red"};

#define		MAXTHREEDCOLORS	61

static const char *theTDColorNames[]={"00", "20", "35", "50", "70", "90",
				"a5", "b9", "d0", "e5", "ff"};

static const char *theTDPSColorNames[]={"0.0 ", "0.1 ", "0.2 ", "0.3 ",
				  "0.4 ", "0.5 ", "0.6 ", "0.7 ",
				  "0.8 ", "0.9 ", "1.0 "};

/****************************************/

static const char *theFontName = "fixed\0";




typedef struct window_struct *WindowType;
struct window_struct {
  int             ulxc;
  int             ulyc;
  int             lrxc;
  int             lryc;
  int             state;
  DataType        data;
  LabelType       label;
  SCALAR          theta;
  SCALAR          phi;
  char            eps_file_name[MAX_BUFFER_SIZE];
  char            plot_title[MAX_BUFFER_SIZE];
  GC              xwingc;
  Pixmap          pixmap_buffer;
  void            (*paint_function) (WindowType);
  void            (*print_function) (WindowType, const char*, const char*);
  void            (*ascii_print_function) (WindowType, const char*, char);
  void            (*xgrafix_print_function) (WindowType, const char*, char);
  Tk_Window       tkwin;
  MeshType      **theMesh;
  double          c1,d1,c2,d2;
  int             mstart, mend, nstart, nend, xSize, ySize;
  StructType     *structures;
  int            *openFlag;
  char            type;
};

typedef struct string_struct {
  char            buffer[20];
  SCALAR          x;
  SCALAR          y;
}               StringType;

/********************************************/
/********************************************/
/* Global variables used in XGRAFIX         */


WindowType     *theWindowArray;
int             sizeIncrement;
int             sizeOfWindowArray;
int             numberOfWindows; 

/* Variables for Special Button List, Payam 7.92 */
/* List changed to array, Don 7.94 */
SpecialType    *theSpecialArray; 
int             specialSizeIncrement;
int             sizeOfSpecialArray;
int             numberOfSpecials;

double          theCrosshairmx, theCrosshairbx;
double          theCrosshairmy, theCrosshairby;
int             theCrosshairx1, theCrosshairx2;
int             theCrosshairy1, theCrosshairy2;

Font            theFont;
XFontStruct    *theFontStruct;
int             theFontAscent;
int             theFontDescent;
int             theFontHeight;


char            ReqDisp[120];
Display        *theDisplay;
int             theDisplayWidth;
int             theDisplayHeight;

Window          theRootWindow;
int             theScreen;
int             theDepth;

unsigned long   theBlackPixel;
unsigned long   theWhitePixel;
Colormap        theColormap;
int             theWinTextColor;
int             theDBTextColor;
int             theBorderColor;
int             theTickMarkColor;
int             theBKGDColor;
int             GrayShade[MAXGRAYSHADES];
int             Color[MAXCOLORS];
SCALAR          RedColor[MAXCOLORS];
SCALAR          GreenColor[MAXCOLORS];
SCALAR          BlueColor[MAXCOLORS];
int             ThreeDColor[MAXTHREEDCOLORS];
char            ThreeDPSColor[MAXTHREEDCOLORS][20];
SCALAR          init_theta, init_phi;

Tcl_Interp     *interp;
char            TclCommand[2048]; // 255->2048; changed by JK, 2020-01-02 255->204
Tk_Window       mainWindow;
WindowType      theNewWindow;
int             theRunWithXFlag;
/*int             theExitFlag;*/

void            XpmToGif(char **xpmData, const char *outFile);
DataType        SetupDataStruct(void);
LabelType       SetupLabelStruct(void);

int             xindex_3d_plots;
int             yindex_3d_plots;
int             zindex_3d_plots;
int             windex_3d_plots;
SCALAR        **xplot3d[MAX_3D_PLOTS];
SCALAR        **yplot3d[MAX_3D_PLOTS];
SCALAR        **zplot3d[MAX_3D_PLOTS];
SCALAR        **wplot3d[MAX_3D_PLOTS];

short           ToShort(SCALAR);
int             findlen(const char *);
void            Paint_Window(WindowType);
void            Paint_Vector_Window(WindowType);
void            Paint_ThreeD_Window(WindowType);
void            PostScriptOpenWindow(WindowType, const char *, const char *);
void            PostScript_ThreeD_Window(WindowType, const char *, const char *);
void            PostScript_Vector_Window(WindowType, const char *, const char *);
void            Ascii_ThreeD_Window(WindowType, const char *, char);
void            Ascii_TwoD_Window(WindowType, const char *, char);
void            Ascii_Vector_Window(WindowType, const char *, char);
void            XGInit(int argc, char **argv, double *t);
void            XGInitX(void);
void            XGInitTclTk(void);
void 	        XGSetVec(const char *type, const char *xlabel,
			 const char *ylabel, const char *zlabel,
			 const char *state, int ulx,
			 int uly, SCALAR xscale, SCALAR yscale, 
			 int xautorescale, int yautorescale, 
			 SCALAR xmin, SCALAR xmax, SCALAR ymin,
			 SCALAR ymax);
void 	        XGSet2D(const char *type, const char *xlabel,
			const char *ylabel,
			const char *state, int ulx, int uly, SCALAR xscale,
			SCALAR yscale, int xautorescale, 
			int yautorescale, SCALAR xmin, SCALAR xmax, 
			SCALAR ymin, SCALAR ymax);
void 	        XGSet2D_OS(const char *type, const char *xlabel,
			const char *ylabel,
			const char *state, int ulx, int uly, SCALAR xoffset,
			SCALAR yoffset, SCALAR xscale,
			SCALAR yscale, int xautorescale, 
			int yautorescale, SCALAR xmin, SCALAR xmax, 
			SCALAR ymin, SCALAR ymax);
void 	        XGSet2DC(const char *type, const char *xlabel,
			 const char *ylabel,
			 const char *zlabel, const char *state, int ulx,
			 int uly, SCALAR xscale, SCALAR yscale,
			 SCALAR zscale, int xautorescale, 
			 int yautorescale, int zautorescale, 
			 SCALAR xmin, SCALAR xmax, SCALAR ymin, 
			 SCALAR ymax, SCALAR zmin, SCALAR zmax);
void 	        XGSet3D(const char *type, const char *xlabel,
			const char *ylabel,
			const char *zlabel, SCALAR theta, SCALAR phi,
			const char *state, int ulx, int uly, SCALAR xscale,
			SCALAR yscale, SCALAR zscale, 
			int xautorescale, int yautorescale, 
			int zautorescale, SCALAR xmin, SCALAR xmax, 
			SCALAR ymin, SCALAR ymax, SCALAR zmin, 
			SCALAR zmax);
void XGVector(SCALAR *xdata, SCALAR *ydata, SCALAR **zdata, SCALAR **wdata, int *mpoints, int *npoints, int color);
void XGVectorWithLabel(SCALAR *x_array, SCALAR *y_array, SCALAR **z_array,
			SCALAR **w_array, int *mpoints, int *npoints, int color, char *label);		// JK 2019-01-16

void XGVectorVector(SCALAR *xdata, SCALAR *ydata, SCALAR **zdata, SCALAR **wdata,
			int *mpoints, int *npoints, int color, int xSize, int xOffset, int ySize,
			int yOffset, int zSize, int zOffset, int wSize, int wOffset);
void XGVectorVectorWithLabel(SCALAR *xdata, SCALAR *ydata, SCALAR **zdata, SCALAR **wdata,
			int *mpoints, int *npoints, int color, int xSize, int xOffset, int ySize,
			int yOffset, int zSize, int zOffset, int wSize, int wOffset, char *label);		// JK 2019-01-16
     
void XGSurf(SCALAR *xdata, SCALAR *ydata, SCALAR **zdata, int *mpoints, int *npoints, int color);
void XGSurfWithLabel(SCALAR *x_array, SCALAR *y_array, SCALAR **z_array, int *mpoints,
			int *npoints, int color, char *label);			// JK 2019-01-16
void XGSurfVector(SCALAR *xdata, SCALAR *ydata, SCALAR **zdata, int *mpoints, int *npoints,
			int color, int xSize, int xOffset, int ySize, int yOffset, int zSize, int zOffset);
void XGSurfVectorWithLabel(SCALAR *xdata, SCALAR *ydata, SCALAR **zdata, int *mpoints, int *npoints,
			int color, int xSize, int xOffset, int ySize, int yOffset, int zSize, int zOffset, char *label);		// JK 2019-01-16

void XGCurve(SCALAR *xdata, SCALAR *ydata, int *npoints, int color);
void XGCurveWithLabel(SCALAR *xdata, SCALAR *ydata, int *npoints, int color, char *label);		// JK, 2019-01-16
void XGCurveVector(SCALAR *xdata, SCALAR *ydata, int *npoints, int color, int xSize, int xOffset, int ySize, int yOffset);
void XGCurveVectorWithLabel(SCALAR *xdata, SCALAR *ydata, int *npoints, int color, int xSize, int xOffset,
			int ySize, int yOffset, char *label);		// JK, 2019-01-16

void XGIRSurf(SCALAR **xdata, SCALAR **ydata, SCALAR **zdata, int *mpoints, int *nponits, int color);
void XGIRSurfWithLabel(SCALAR **x_array, SCALAR **y_array, SCALAR **z_array, int *mpoints, int *npoints, int color, char *label);	// JK 2019-01-16

void XGIRSurfVector(SCALAR **xdata, SCALAR **ydata, SCALAR **zdata, int *mpoints, int *npoints, int color, int xSize,
			int xOffset, int ySize, int yOffset, int zSize, int zOffset);
void XGIRSurfVectorWithLabel(SCALAR **xdata, SCALAR **ydata, SCALAR **zdata, int *mpoints, int *npoints, int color,
			int xSize, int xOffset, int ySize, int yOffset, int zSize, int zOffset, char *label);			// JK 2019-01-16

void XGScat2D(SCALAR *xdata, SCALAR *ydata, int *npoints, int color);
void XGScat2DWithLabel(SCALAR *xdata, SCALAR *ydata, int *npoints, int color, char *label);		// JK, 2019-01-16

void XGScat3D(SCALAR *xdata, SCALAR *ydata, SCALAR *zdata, int *npoints, int color);
void XGScat3DWithLabel(SCALAR *x_array, SCALAR *y_array, SCALAR *z_array, int *npoints, int color, char *label);		// JK, 2019-01-16

void XGCont(SCALAR *xdata, SCALAR *data, SCALAR **zdata, int *mpoints, int *npoints, int color);
void XGContWithLabel(SCALAR *x_array, SCALAR *y_array, SCALAR **z_array, int *mpoints, int *npoints, int color, char *label);	// JK 2019-01-16

void 		XGStart(void);
void        XGMainLoop(void);
int 		C_UpdateCrosshairProc _ANSI_ARGS_ ((ClientData, Tcl_Interp *, int, const char **));
int 		C_SetCrosshairParametersProc _ANSI_ARGS_ ((ClientData, Tcl_Interp *, int, const char **));
void 		XG_Setup_Pixmap(WindowType);
void 		Setup(void);
void 		Main(void);
void 		RedrawWindow(WindowType);
void 		DoGraphics(ClientData);
void 		DoMain(ClientData);
void 		SortWindows(void);
int 		Search(const char *);
void 		XGSetupWindow(const char *, const char *, int, int, int, DataType, LabelType, int);
void 		InitTclCommands(void);
void 		PSHeader(const char *);
void 		XG_Copy_Pixmap(WindowType);
void 		ReallocateWindows(void);
void 		SetUpNewVar(void *, const char *, const char *);
void		Dump(const char *);
void		Quit(void);
void            DrawCrosshair(WindowType, int, int);
void            RescaleTwoDWindow(WindowType theWindow);
void            RescaleVectorDWindow(WindowType theWindow, int *ms, int *me, 
				     int *ns, int *ne);
void            RescaleThreeDWindow(WindowType theWindow, int *ms, int *me, 
				    int *ns, int *ne);

// void XGWriteLabel(LabelType theLabel, FILE *fp);
// void XGWriteStructures(StructType *structures, const char *filename);
// void XGRead(void *ptr,int size,int nitems,FILE * stream,const char * type);
void Bin_Vector_Window(WindowType theWindow, const char *filename, char type);
void Bin_ThreeD_Window(WindowType theWindow, const char *filename, char type);
void Bin_TwoD_Window(WindowType theWindow, const char *filename, char type);
extern void XGStructureArray(int npoints, STRUCT_FILL fillFlag, int linecolor, int fillcolor, SCALAR *points);


#endif /* XGRAFIXINT_H */
